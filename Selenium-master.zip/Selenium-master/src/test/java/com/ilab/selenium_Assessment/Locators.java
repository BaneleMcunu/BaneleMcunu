package com.ilab.selenium_Assessment;

public class Locators {
	static String login_user_name = "txtUsername"; 
	static String login_password = "txtPassword";
	static String login_button = "btnLogin";
	
	static String admin_tab = "menu_admin_viewAdminModule";
	static String add_button = "btnAdd";
	static String Add_User = "UserHeading";
	
	
	static String role = "systemUser_userType";
	static String employee_name = "systemUser_employeeName_empName";
	static String Username = "systemUser_userName";
	static String status = "sytemUser_status";
	
	
	static String Password = "systemUser_password";
	static String Confirm_Password = "systemUser_confirmPassword";
	static String save_button = "btnSave";
	static String search_Username = "searchSystemUser[userName]";
	
	
	static String search_button = "searchBtn";
	static String reset_button = "resetBtn";	
	static String recently_added_radio = "chkSelectRow[]";
	static String delete_button = "btnDelete";
	
	
	static String ok_button = "dialogDeleteBtn";
	static String welcome_admin = "welcome";
	static String logout = "Logout";

}
