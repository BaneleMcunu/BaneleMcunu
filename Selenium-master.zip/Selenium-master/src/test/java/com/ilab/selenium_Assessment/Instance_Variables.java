package com.ilab.selenium_Assessment;

public class Instance_Variables {
	static String login_user_name = "Admin"; 
	static String login_password = "admin123";
	static String admin_tab = "Admin";
	static String role = "ESS";
	static String employee_name = "Jasmine Morgan";
	static String Username = "Selenium12693";
	static String status = "Enabled";
	static String Password = "Selenium500";
	static String searchName = "Selenium500";
	static String Confirm_Password = Password;
	static String search_Username = Username;


}
